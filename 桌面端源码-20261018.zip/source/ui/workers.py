"""Qt task dispatch with parallel reads, serialized writes and safe shutdown."""
from __future__ import annotations

import logging
import secrets
import threading
import traceback

from PySide6.QtCore import QObject, QRunnable, QThreadPool, Signal, Slot

from domain import BackendChangedError, StorageError
from services.read_control import ReadCancelled, read_scope


class WorkerSignals(QObject):
    result = Signal(str, object)
    error = Signal(str, object)
    progress = Signal(str, int, str)
    finished = Signal(str)


class Worker(QRunnable):
    def __init__(self, job_id, function, write=False):
        super().__init__()
        self.setAutoDelete(False)
        self.job_id = job_id
        self.function = function
        self.write = write
        self.signals = WorkerSignals()
        self.cancelled = threading.Event()

    @Slot()
    def run(self):
        try:
            if not self.cancelled.is_set():
                self.signals.progress.emit(self.job_id, 0, "处理中…")
                with read_scope(None if self.write else self.cancelled):
                    result = self.function()
                self.signals.result.emit(self.job_id, result)
        except ReadCancelled:
            pass
        except ValueError as exc:
            self.signals.error.emit(self.job_id, exc)
        except Exception as exc:
            logging.error("Background task failed (%s)\n%s", type(exc).__name__, "".join(traceback.format_tb(exc.__traceback__)))
            self.signals.error.emit(self.job_id, StorageError("操作失败，请检查文件权限或 data/app.log"))
        finally:
            self.signals.finished.emit(self.job_id)


class TaskManager(QObject):
    busyChanged = Signal(bool)
    writesChanged = Signal(int)
    allFinished = Signal()
    progress = Signal(int, str)

    def __init__(self, context, parent=None):
        super().__init__(parent)
        self.context = context
        self.read_pool = QThreadPool(self)
        self.read_pool.setMaxThreadCount(3)
        self.write_pool = QThreadPool(self)
        self.write_pool.setMaxThreadCount(1)
        self.jobs = {}
        self.closing = False

    @property
    def write_count(self):
        return sum(job["write"] for job in self.jobs.values())

    def submit(self, function, result, error, *, generation=None, write=False, allow_generation_change=False,
               latest_key=None):
        if self.closing:
            return None
        if write and latest_key is not None:
            raise ValueError("写入任务不能被新查询取消")
        if latest_key is not None:
            self._cancel_reads(latest_key)
        job_id = secrets.token_hex(8)
        worker = Worker(job_id, function, write)
        self.jobs[job_id] = {"worker": worker, "result": result, "error": error,
                             "generation": generation, "write": write, "allow_change": allow_generation_change,
                             "data_generation": self.context.data_generation, "latest_key": latest_key}
        worker.signals.result.connect(self._result)
        worker.signals.error.connect(self._error)
        worker.signals.progress.connect(self._progress)
        worker.signals.finished.connect(self._finished)
        self.busyChanged.emit(True)
        self.writesChanged.emit(self.write_count)
        (self.write_pool if write else self.read_pool).start(worker)
        return job_id

    def _cancel_reads(self, latest_key=None):
        for job_id, job in list(self.jobs.items()):
            if not job["write"] and (latest_key is None or job["latest_key"] == latest_key):
                worker = job["worker"]
                worker.cancelled.set()
                if self.read_pool.tryTake(worker):
                    self.jobs.pop(job_id, None)

    def cancel_reads(self, latest_key):
        self._cancel_reads(latest_key)
        self._emit_state()

    @Slot(str, object)
    def _result(self, job_id, value):
        job = self.jobs.get(job_id)
        if not job or self.closing or job["worker"].cancelled.is_set():
            return
        if not job["write"] and job["data_generation"] != self.context.data_generation:
            return
        if job["generation"] and job["generation"] != self.context.storage_generation and not job["allow_change"]:
            if job["write"]:
                job["error"](BackendChangedError("数据库已切换，请重新操作"))
            return
        job["result"](value)

    @Slot(str, object)
    def _error(self, job_id, error):
        job = self.jobs.get(job_id)
        if job and not self.closing and not job["worker"].cancelled.is_set():
            if not job["write"] and job["data_generation"] != self.context.data_generation:
                return
            if job["generation"] and job["generation"] != self.context.storage_generation and not job["write"]:
                return
            job["error"](error)

    @Slot(str, int, str)
    def _progress(self, job_id, amount, message):
        if job_id in self.jobs:
            self.progress.emit(amount, message)

    @Slot(str)
    def _finished(self, job_id):
        self.jobs.pop(job_id, None)
        self._emit_state()

    def _emit_state(self):
        self.busyChanged.emit(bool(self.jobs))
        self.writesChanged.emit(self.write_count)
        if not self.jobs:
            self.allFinished.emit()

    def begin_shutdown(self):
        self.closing = True
        self._cancel_reads()
        # A running urllib call completes by its timeout; a write always finishes.
        self._emit_state()
