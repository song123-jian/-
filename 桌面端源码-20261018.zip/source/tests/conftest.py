import sys
from pathlib import Path

import pytest

SOURCE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SOURCE))

from services.app_context import AppContext
from services.price_service import PriceService
from storage.sqlite_store import SQLiteStore


@pytest.fixture
def store(tmp_path):
    return SQLiteStore(tmp_path)


@pytest.fixture
def context(store, tmp_path):
    return AppContext(store, tmp_path)


@pytest.fixture
def service(context):
    return PriceService(context)


def record(**changes):
    value = {"customer": "QA隔离客户", "grade": "QA-PP", "material": "PP-TD20", "color": "本色",
             "price": "10.5", "tax_type": "含税", "effective_date": "2026-09-01", "note": "原报价", "reason": ""}
    value.update(changes)
    return value
