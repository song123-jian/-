param([string]$Python = '', [string]$OutputDirectory = '', [switch]$SkipTests)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
if (-not $Python) { $Python = Join-Path $projectRoot '.venv\Scripts\python.exe' }
if (-not $OutputDirectory) { $OutputDirectory = Join-Path $projectRoot 'work\release' }
$Python = (Resolve-Path -LiteralPath $Python).Path
$buildRoot = Join-Path $projectRoot '.build'
$accountAssets = Join-Path $buildRoot 'account-assets'
New-Item -ItemType Directory -Path $accountAssets -Force | Out-Null
$accountSeed = Join-Path $accountAssets 'seed.json'
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'account_seed.json') -Destination $accountSeed -Force
$rcc = Join-Path (Split-Path -Parent $Python) 'pyside6-rcc.exe'
if (Get-Command node -ErrorAction SilentlyContinue) { & node (Join-Path $PSScriptRoot 'build_icons.js') }
& $rcc (Join-Path $PSScriptRoot 'resources.qrc') -o (Join-Path $PSScriptRoot 'ui\resources_rc.py')
if ($LASTEXITCODE -ne 0) { throw 'Qt resource compilation failed' }
if (-not $SkipTests) {
    & $Python -m ruff check $PSScriptRoot
    if ($LASTEXITCODE -ne 0) { throw 'Static review failed' }
    & $Python -m pytest (Join-Path $PSScriptRoot 'tests') -q
    if ($LASTEXITCODE -ne 0) { throw 'Regression tests failed' }
}
& $Python -m PyInstaller --noconfirm --clean --onefile --windowed `
    --name '价格查询桌面版' --distpath $OutputDirectory `
    --workpath (Join-Path $buildRoot 'desktop-work') --specpath $buildRoot `
    --paths $PSScriptRoot --exclude-module PySide6.QtWebEngineCore `
    --exclude-module PySide6.QtWebEngineWidgets --exclude-module PySide6.QtPdf `
    --collect-data rapidocr --hidden-import rapidocr.inference_engine.onnxruntime `
    --add-data ($accountSeed + ';.') `
    --add-data ((Join-Path $PSScriptRoot 'account_config.json') + ';.') `
    --add-data ((Join-Path $PSScriptRoot 'supabase.sql') + ';.') `
    --add-data ((Join-Path $PSScriptRoot 'migrations') + ';migrations') `
    --add-data ((Join-Path $PSScriptRoot 'business_templates') + ';business_templates') `
    (Join-Path $PSScriptRoot 'desktop_main.py')
if ($LASTEXITCODE -ne 0) { throw 'Desktop EXE build failed' }
Write-Output (Join-Path $OutputDirectory '价格查询桌面版.exe')
