"""GUI-independent application services."""
