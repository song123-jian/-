# 私有单据模板

本公开源码包不包含原项目的印章、银行账号及联系方式图片。使用单据导出前，请在本机自行配置 contract.png、quotation.png、contract-seal.png 和 quotation-seal.png。原项目文件保留在用户电脑，未修改或删除。
